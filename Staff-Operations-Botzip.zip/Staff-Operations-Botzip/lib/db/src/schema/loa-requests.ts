import { createInsertSchema } from "drizzle-zod";
import {
  date,
  integer,
  pgTable,
  text,
  timestamp,
} from "drizzle-orm/pg-core";
import { z } from "zod/v4";

export const loaRequestsTable = pgTable("loa_requests", {
  id: integer("id").generatedAlwaysAsIdentity().primaryKey(),
  guildId: text("guild_id").notNull(),
  requesterId: text("requester_id").notNull(),
  requesterName: text("requester_name").notNull(),
  requestText: text("request_text").notNull(),
  startDate: date("start_date", { mode: "string" }).notNull(),
  endDate: date("end_date", { mode: "string" }).notNull(),
  status: text("status").notNull().default("pending"),
  decidedById: text("decided_by_id"),
  decidedByName: text("decided_by_name"),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true })
    .notNull()
    .defaultNow()
    .$onUpdate(() => new Date()),
});

export const insertLoaRequestSchema = createInsertSchema(
  loaRequestsTable,
).omit({ createdAt: true, updatedAt: true });
export type InsertLoaRequest = z.infer<typeof insertLoaRequestSchema>;
export type LoaRequest = typeof loaRequestsTable.$inferSelect;