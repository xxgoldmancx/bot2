import { createInsertSchema } from "drizzle-zod";
import { pgTable, text, timestamp } from "drizzle-orm/pg-core";
import { z } from "zod/v4";

export const staffRoleConfigsTable = pgTable("staff_role_configs", {
  guildId: text("guild_id").primaryKey(),
  ownerRoleId: text("owner_role_id").notNull(),
  adminRoleId: text("admin_role_id").notNull(),
  managerRoleId: text("manager_role_id").notNull(),
  staffRoleId: text("staff_role_id").notNull(),
  loaApproverRoleIds: text("loa_approver_role_ids").array().notNull().default([]),
  updatedAt: timestamp("updated_at", { withTimezone: true })
    .notNull()
    .defaultNow()
    .$onUpdate(() => new Date()),
});

export const insertStaffRoleConfigSchema = createInsertSchema(
  staffRoleConfigsTable,
).omit({ updatedAt: true });
export type InsertStaffRoleConfig = z.infer<
  typeof insertStaffRoleConfigSchema
>;
export type StaffRoleConfig = typeof staffRoleConfigsTable.$inferSelect;