export type StaffProfile = {
  name: string;
  role: string;
  initials: string;
};

export type Capability = {
  id: string;
  label: string;
  description: string;
  category: string;
  available: boolean;
  requiresConfirmation: boolean;
};

export type ActivityItem = {
  id: string;
  action: string;
  detail?: string | null;
  status: 'completed' | 'pending' | 'blocked';
  actor: string;
  timestamp: string;
};

export type SuggestedAction = {
  id: string;
  label: string;
  description: string;
  tone: 'neutral' | 'positive' | 'warning';
  requiresConfirmation: boolean;
};

export type ChatMessage = {
  id: string;
  conversationId: string;
  text: string;
  timestamp: string;
  actions: SuggestedAction[];
  from: 'staff' | 'assistant';
};