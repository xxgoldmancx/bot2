import { useMemo, useState } from 'react';
import { Activity, AlertCircle, CheckCircle2, Clock3, Filter, Search, ShieldAlert } from 'lucide-react';
import { useGetAssistantActivity, getGetAssistantActivityQueryKey } from '@workspace/api-client-react';
import { EmptyState, PageHeading } from '@/components/app-shell';
import { PageSkeleton } from '@/components/skeletons';
import type { ActivityItem } from '@/lib/types';

function formatDate(timestamp: string) {
  const date = new Date(timestamp);
  if (Number.isNaN(date.getTime())) return timestamp;
  return new Intl.DateTimeFormat(undefined, { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' }).format(date);
}

function StatusBadge({ status }: { status: ActivityItem['status'] }) {
  const config = {
    completed: { label: 'Completed', icon: CheckCircle2, classes: 'bg-[hsl(var(--accent)/.35)] text-[hsl(var(--foreground))]' },
    pending: { label: 'Pending', icon: Clock3, classes: 'bg-[hsl(var(--chart-4)/.18)] text-[hsl(var(--foreground))]' },
    blocked: { label: 'Blocked', icon: ShieldAlert, classes: 'bg-[hsl(var(--destructive)/.12)] text-[hsl(var(--destructive))]' },
  }[status];
  const Icon = config.icon;
  return <span className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 font-mono text-[9px] uppercase tracking-[.08em] ${config.classes}`} data-testid={`status-activity-${status}`}><Icon size={11} /> {config.label}</span>;
}

export default function ActivityPage() {
  const { data: activity, isLoading, isError, refetch } = useGetAssistantActivity({ query: { queryKey: getGetAssistantActivityQueryKey() } });
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState<'all' | ActivityItem['status']>('all');
  const filtered = useMemo(() => (activity ?? []).filter((item) => {
    const matchesFilter = filter === 'all' || item.status === filter;
    const haystack = `${item.action} ${item.detail ?? ''} ${item.actor}`.toLowerCase();
    return matchesFilter && haystack.includes(search.toLowerCase());
  }), [activity, filter, search]);

  return <div className="mx-auto max-w-6xl px-5 pb-28 pt-10 lg:px-10 lg:pb-12 lg:pt-12">
    <PageHeading eyebrow="Audit and visibility" title="Activity trail" description="A searchable record of what the assistant has done, proposed, or stopped before making a change." />
    <div className="mt-9 rounded-2xl border border-[hsl(var(--border))] bg-[hsl(var(--card))] shadow-[var(--shadow-sm)]">
      <div className="flex flex-col gap-3 border-b border-[hsl(var(--border))] p-4 sm:flex-row sm:items-center sm:justify-between"><label className="flex min-w-0 flex-1 items-center gap-2 rounded-lg border border-[hsl(var(--input))] bg-[hsl(var(--background))] px-3 py-2.5 focus-within:border-[hsl(var(--foreground))]"><Search size={15} className="shrink-0 text-[hsl(var(--muted-foreground))]" /><input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Search actions, detail, or actor" className="min-w-0 flex-1 bg-transparent text-sm outline-none placeholder:text-[hsl(var(--muted-foreground))]" data-testid="input-search-activity" /></label><div className="flex items-center gap-2"><Filter size={14} className="text-[hsl(var(--muted-foreground))]" /><select value={filter} onChange={(event) => setFilter(event.target.value as typeof filter)} className="rounded-lg border border-[hsl(var(--input))] bg-[hsl(var(--background))] px-3 py-2.5 text-xs font-semibold outline-none" data-testid="select-activity-filter"><option value="all">All statuses</option><option value="completed">Completed</option><option value="pending">Pending</option><option value="blocked">Blocked</option></select></div></div>
      {isLoading ? <div className="space-y-4 p-5">{[1, 2, 3, 4].map((item) => <div key={item} className="flex animate-pulse gap-4"><div className="size-9 rounded-lg bg-[hsl(var(--muted))]" /><div className="flex-1 space-y-2"><div className="h-3 w-1/3 rounded bg-[hsl(var(--muted))]" /><div className="h-3 w-2/3 rounded bg-[hsl(var(--muted))]" /></div></div>)}</div> : isError ? <div className="px-6 py-16 text-center"><AlertCircle className="mx-auto text-[hsl(var(--destructive))]" /><p className="mt-3 text-sm font-semibold">Could not load the activity trail</p><button onClick={() => refetch()} className="mt-4 rounded-lg bg-[hsl(var(--foreground))] px-4 py-2 text-xs font-semibold text-[hsl(var(--background))]" data-testid="button-retry-activity">Try again</button></div> : filtered.length === 0 ? <div className="p-5"><EmptyState icon={Activity} title={search || filter !== 'all' ? 'No matching activity' : 'No activity yet'} text={search || filter !== 'all' ? 'Try a different search or status filter.' : 'Completed operations and assistant proposals will appear here.'} /></div> : <div className="divide-y divide-[hsl(var(--border))]">{filtered.map((item) => <article key={item.id} className="group flex flex-col gap-4 p-5 transition-colors hover:bg-[hsl(var(--background)/.58)] sm:flex-row sm:items-start" data-testid={`row-activity-${item.id}`}><div className="grid size-9 shrink-0 place-items-center rounded-lg bg-[hsl(var(--secondary))] text-[hsl(var(--muted-foreground))]"><Activity size={16} /></div><div className="min-w-0 flex-1"><div className="flex flex-wrap items-center gap-2"><h2 className="text-sm font-semibold">{item.action}</h2><StatusBadge status={item.status} /></div><p className="mt-1.5 text-xs leading-5 text-[hsl(var(--muted-foreground))]">{item.detail || 'No additional detail recorded.'}</p><div className="mt-3 flex flex-wrap gap-x-4 gap-y-1 font-mono text-[9px] uppercase tracking-[.07em] text-[hsl(var(--muted-foreground))]"><span data-testid={`text-activity-actor-${item.id}`}>Actor · {item.actor}</span><span data-testid={`text-activity-time-${item.id}`}>{formatDate(item.timestamp)}</span></div></div></article>)}</div>}
      {!isLoading && !isError && filtered.length > 0 && <div className="border-t border-[hsl(var(--border))] px-5 py-3 font-mono text-[9px] uppercase tracking-[.12em] text-[hsl(var(--muted-foreground))]" data-testid="text-activity-count">{filtered.length} {filtered.length === 1 ? 'entry' : 'entries'} shown</div>}
    </div>
  </div>;
}