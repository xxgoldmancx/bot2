import { AlertCircle } from 'lucide-react';

export default function NotFound() {
  return (
    <div className="grid min-h-[calc(100dvh-72px)] place-items-center px-6">
      <div className="w-full max-w-md rounded-2xl border border-[hsl(var(--border))] bg-[hsl(var(--card))] p-7 shadow-[var(--shadow)]">
        <div className="flex items-start gap-4">
          <div className="grid size-10 shrink-0 place-items-center rounded-xl bg-[hsl(var(--destructive)/.12)] text-[hsl(var(--destructive))]"><AlertCircle size={20} /></div>
          <div><p className="font-mono text-[10px] uppercase tracking-[.16em] text-[hsl(var(--muted-foreground))]">Signal lost · 404</p><h1 className="mt-2 text-xl font-bold tracking-[-.04em]">That route does not exist.</h1><p className="mt-2 text-sm leading-6 text-[hsl(var(--muted-foreground))]">Use the workspace navigation to return to the command center.</p></div>
        </div>
      </div>
    </div>
  );
}
