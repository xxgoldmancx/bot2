import { useEffect, useMemo, useRef, useState } from 'react';
import { AlertCircle, ArrowUp, Check, ChevronRight, Clock3, FileText, Loader2, LockKeyhole, Plus, Search, Sparkles, Terminal, X } from 'lucide-react';
import { useQueryClient } from '@tanstack/react-query';
import { useGetAssistantContext, useSendAssistantMessage, useExecuteAssistantAction, getGetAssistantContextQueryKey, getGetAssistantActivityQueryKey } from '@workspace/api-client-react';
import { Link } from 'wouter';
import { ChatSkeleton } from '@/components/skeletons';
import { PageHeading } from '@/components/app-shell';
import type { ActivityItem, ChatMessage, SuggestedAction } from '@/lib/types';

function timeLabel(date: string) {
  const value = new Date(date);
  if (Number.isNaN(value.getTime())) return 'just now';
  return value.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
}

function ActionCard({ action, onExecute, pending }: { action: SuggestedAction; onExecute: (action: SuggestedAction) => void; pending: boolean }) {
  const tone = action.tone === 'positive' ? 'border-[hsl(var(--accent)/.7)] bg-[hsl(var(--accent)/.18)]' : action.tone === 'warning' ? 'border-[hsl(var(--destructive)/.35)] bg-[hsl(var(--destructive)/.08)]' : 'border-[hsl(var(--border))] bg-[hsl(var(--card))]';
  return <div className={`mt-4 max-w-md rounded-xl border p-4 ${tone}`} data-testid={`card-proposed-action-${action.id}`}>
    <div className="flex items-start gap-3"><div className="mt-0.5 grid size-7 shrink-0 place-items-center rounded-lg bg-[hsl(var(--foreground))] text-[hsl(var(--background))]"><Terminal size={13} /></div><div className="min-w-0 flex-1"><div className="flex items-center gap-2"><p className="text-sm font-semibold">{action.label}</p>{action.requiresConfirmation && <span className="font-mono text-[9px] uppercase tracking-[.08em] text-[hsl(var(--muted-foreground))]">approval needed</span>}</div><p className="mt-1 text-xs leading-5 text-[hsl(var(--muted-foreground))]">{action.description}</p></div></div>
    <button disabled={pending} onClick={() => onExecute(action)} className="mt-4 flex w-full items-center justify-between rounded-lg bg-[hsl(var(--foreground))] px-3 py-2.5 text-xs font-semibold text-[hsl(var(--background))] transition-transform hover:-translate-y-0.5 disabled:cursor-wait disabled:opacity-55" data-testid={`button-execute-action-${action.id}`}><span>{pending ? 'Working…' : action.requiresConfirmation ? 'Review and run' : 'Run action'}</span>{pending ? <Loader2 size={14} className="animate-spin" /> : <ChevronRight size={14} />}</button>
  </div>;
}

function ConfirmPanel({ action, onConfirm, onCancel, pending }: { action: SuggestedAction; onConfirm: (note: string) => void; onCancel: () => void; pending: boolean }) {
  const [note, setNote] = useState('');
  return <div className="fixed inset-0 z-50 grid place-items-center bg-[hsl(var(--foreground)/.34)] p-4 backdrop-blur-sm" role="dialog" aria-modal="true" data-testid="dialog-confirm-action"><div className="w-full max-w-md rounded-2xl border border-[hsl(var(--border))] bg-[hsl(var(--card))] p-6 shadow-[var(--shadow-xl)]"><div className="flex items-start justify-between"><div><div className="grid size-10 place-items-center rounded-xl bg-[hsl(var(--accent))] text-[hsl(var(--accent-foreground))]"><LockKeyhole size={19} /></div><h2 className="mt-5 text-xl font-bold tracking-[-.04em]">Confirm operation</h2><p className="mt-2 text-sm leading-5 text-[hsl(var(--muted-foreground))]">The assistant is ready to {action.label.toLowerCase()}. Check the details before anything changes.</p></div><button onClick={onCancel} className="rounded-lg p-2 text-[hsl(var(--muted-foreground))] hover:bg-[hsl(var(--muted))]" data-testid="button-close-confirm"><X size={17} /></button></div><div className="mt-5 rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--background))] p-4"><p className="text-sm font-semibold">{action.label}</p><p className="mt-1 text-xs leading-5 text-[hsl(var(--muted-foreground))]">{action.description}</p></div><label className="mt-5 block"><span className="text-xs font-semibold">Note <span className="font-normal text-[hsl(var(--muted-foreground))]">(optional)</span></span><textarea value={note} onChange={(event) => setNote(event.target.value)} placeholder="Add context for the activity trail" className="mt-2 min-h-20 w-full resize-none rounded-lg border border-[hsl(var(--input))] bg-[hsl(var(--background))] px-3 py-2 text-sm outline-none transition-colors placeholder:text-[hsl(var(--muted-foreground))] focus:border-[hsl(var(--foreground))]" data-testid="textarea-action-note" /></label><div className="mt-5 flex gap-2"><button onClick={onCancel} className="flex-1 rounded-lg border border-[hsl(var(--border))] px-4 py-2.5 text-xs font-semibold hover:bg-[hsl(var(--muted))]" data-testid="button-cancel-confirm">Not yet</button><button disabled={pending} onClick={() => onConfirm(note)} className="flex flex-1 items-center justify-center gap-2 rounded-lg bg-[hsl(var(--foreground))] px-4 py-2.5 text-xs font-semibold text-[hsl(var(--background))] disabled:opacity-60" data-testid="button-confirm-action">{pending && <Loader2 size={14} className="animate-spin" />} Confirm and run</button></div></div></div>;
}

export default function Home() {
  const queryClient = useQueryClient();
  const { data: context, isLoading, isError, refetch } = useGetAssistantContext({ query: { queryKey: getGetAssistantContextQueryKey() } });
  const sendMessage = useSendAssistantMessage();
  const executeAction = useExecuteAssistantAction();
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [draft, setDraft] = useState('');
  const [conversationId, setConversationId] = useState<string | null>(null);
  const [confirming, setConfirming] = useState<SuggestedAction | null>(null);
  const [runningId, setRunningId] = useState<string | null>(null);
  const [actionResult, setActionResult] = useState<{ success: boolean; message: string; activity?: ActivityItem } | null>(null);
  const endRef = useRef<HTMLDivElement>(null);
  const suggested = useMemo(() => context?.suggestedPrompts?.slice(0, 4) ?? [], [context?.suggestedPrompts]);

  useEffect(() => { endRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [messages.length, sendMessage.isPending]);

  const submit = (message: string) => {
    const clean = message.trim();
    if (!clean || sendMessage.isPending) return;
    setDraft('');
    setActionResult(null);
    const userMessage: ChatMessage = { id: `staff-${Date.now()}`, conversationId: conversationId ?? '', text: clean, timestamp: new Date().toISOString(), actions: [], from: 'staff' };
    setMessages((current) => [...current, userMessage]);
    sendMessage.mutate({ data: { message: clean, conversationId } }, {
      onSuccess: (response) => {
        setConversationId(response.conversationId);
        setMessages((current) => [...current, { ...response, from: 'assistant' }]);
      },
      onError: () => {
        setMessages((current) => [...current, { id: `error-${Date.now()}`, conversationId: conversationId ?? '', text: 'I could not reach the operations layer. Try that again in a moment.', timestamp: new Date().toISOString(), actions: [], from: 'assistant' }]);
      },
    });
  };

  const runAction = (action: SuggestedAction) => {
    if (action.requiresConfirmation) { setConfirming(action); return; }
    execute(action, false);
  };

  const execute = (action: SuggestedAction, confirmation: boolean, note?: string) => {
    setRunningId(action.id);
    executeAction.mutate({ actionId: action.id, data: { confirmation, note: note || null } }, {
      onSuccess: (result) => {
        setActionResult(result);
        setConfirming(null);
        setRunningId(null);
        queryClient.invalidateQueries({ queryKey: getGetAssistantContextQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetAssistantActivityQueryKey() });
      },
      onError: () => { setActionResult({ success: false, message: 'The operation did not complete. Nothing was changed.' }); setRunningId(null); },
    });
  };

  if (isLoading) return <div className="mx-auto max-w-5xl px-5 py-12 lg:px-10"><PageHeading eyebrow="Operations copilot" title="A clear path through the work." description="Loading your workspace and available operations." /><div className="mt-10 rounded-2xl border border-[hsl(var(--border))] bg-[hsl(var(--card))] p-6"><ChatSkeleton /></div></div>;
  if (isError || !context) return <div className="mx-auto max-w-xl px-5 py-24 text-center lg:px-10"><div className="mx-auto grid size-12 place-items-center rounded-xl bg-[hsl(var(--destructive)/.12)] text-[hsl(var(--destructive))]"><AlertCircle size={22} /></div><h1 className="mt-5 text-xl font-bold">Workspace unavailable</h1><p className="mt-2 text-sm leading-6 text-[hsl(var(--muted-foreground))]">We could not load your operations context. The assistant needs that connection to work safely.</p><button onClick={() => refetch()} className="mt-6 rounded-lg bg-[hsl(var(--foreground))] px-4 py-2.5 text-xs font-semibold text-[hsl(var(--background))]" data-testid="button-retry-context">Try again</button></div>;

  return <div className="mx-auto max-w-6xl px-5 pb-28 pt-10 lg:px-10 lg:pb-12 lg:pt-12">
    <div className="flex flex-col justify-between gap-8 border-b border-[hsl(var(--border))] pb-9 sm:flex-row sm:items-end"><PageHeading eyebrow="Discord operations bot" title={`Good morning, ${context.staff.name.split(' ')[0]}.`} description="Staff can message the bot in Discord. Use this space to review capabilities, confirmations, and the activity trail." /><div className="flex shrink-0 items-center gap-2 rounded-full border border-[hsl(var(--border))] bg-[hsl(var(--card))] px-3 py-2 text-xs"><span className={`size-2 rounded-full ${context.online ? 'online-pulse bg-[hsl(var(--accent-foreground))]' : 'bg-[hsl(var(--destructive))]'}`} /><span className="font-medium">{context.online ? 'Discord bot ready' : 'Discord bot offline'}</span></div></div>
    <div className="mt-9 grid gap-8 xl:grid-cols-[minmax(0,1fr)_280px]">
      <section className="min-w-0"><div className="min-h-[430px] rounded-2xl border border-[hsl(var(--border))] bg-[hsl(var(--card))] shadow-[var(--shadow-sm)]"><div className="flex items-center justify-between border-b border-[hsl(var(--border))] px-5 py-4"><div className="flex items-center gap-2"><div className="grid size-7 place-items-center rounded-lg bg-[hsl(var(--foreground))] text-[hsl(var(--accent))]"><Sparkles size={14} /></div><span className="text-xs font-semibold">Operations assistant</span></div><button onClick={() => { setMessages([]); setConversationId(null); setActionResult(null); }} className="flex items-center gap-1.5 text-[10px] font-semibold text-[hsl(var(--muted-foreground))] hover:text-[hsl(var(--foreground))]" data-testid="button-new-conversation"><Plus size={14} /> New thread</button></div><div className="max-h-[510px] overflow-y-auto px-5 py-6 scrollbar-thin"><div className="flex items-start gap-3"><div className="grid size-8 shrink-0 place-items-center rounded-lg bg-[hsl(var(--accent))] text-[hsl(var(--accent-foreground))]"><Sparkles size={15} /></div><div className="max-w-[680px]"><p className="mb-1 text-[10px] font-semibold uppercase tracking-[.1em] text-[hsl(var(--muted-foreground))]">Assistant · now</p><div className="rounded-r-xl rounded-bl-xl bg-[hsl(var(--background))] px-4 py-3 text-sm leading-6">I’m connected to your workspace. What should we take care of?</div></div></div>{messages.map((message) => <div key={message.id} className={`mt-6 flex items-start gap-3 ${message.from === 'staff' ? 'justify-end' : ''}`} data-testid={`message-${message.from}-${message.id}`}><div className={`max-w-[680px] ${message.from === 'staff' ? 'order-first' : ''}`}><p className={`mb-1 text-[10px] font-semibold uppercase tracking-[.1em] text-[hsl(var(--muted-foreground))] ${message.from === 'staff' ? 'text-right' : ''}`}>{message.from === 'staff' ? 'You' : 'Assistant'} · {timeLabel(message.timestamp)}</p><div className={`rounded-xl px-4 py-3 text-sm leading-6 ${message.from === 'staff' ? 'rounded-tr-sm bg-[hsl(var(--foreground))] text-[hsl(var(--background))]' : 'rounded-tl-sm bg-[hsl(var(--background))]'}`}>{message.text}</div>{message.from === 'assistant' && message.actions?.map((action) => <ActionCard key={action.id} action={action} onExecute={runAction} pending={runningId === action.id} />)}</div>{message.from === 'staff' && <div className="grid size-8 shrink-0 place-items-center rounded-lg bg-[hsl(var(--secondary))] text-xs font-bold">{context.staff.initials}</div>}</div>)}{sendMessage.isPending && <div className="mt-6"><ChatSkeleton /></div>}{actionResult && <div className={`mt-5 flex items-start gap-3 rounded-xl border p-4 ${actionResult.success ? 'border-[hsl(var(--accent)/.7)] bg-[hsl(var(--accent)/.14)]' : 'border-[hsl(var(--destructive)/.35)] bg-[hsl(var(--destructive)/.08)]'}`} data-testid="status-action-result">{actionResult.success ? <Check size={16} className="mt-0.5 text-[hsl(var(--accent-foreground))]" /> : <AlertCircle size={16} className="mt-0.5 text-[hsl(var(--destructive))]" />}<p className="text-xs leading-5">{actionResult.message}</p></div>}<div ref={endRef} /></div><form onSubmit={(event) => { event.preventDefault(); submit(draft); }} className="border-t border-[hsl(var(--border))] p-4"><div className="flex items-end gap-2 rounded-xl border border-[hsl(var(--input))] bg-[hsl(var(--background))] p-2 transition-colors focus-within:border-[hsl(var(--foreground))]"><textarea value={draft} onChange={(event) => setDraft(event.target.value)} onKeyDown={(event) => { if (event.key === 'Enter' && !event.shiftKey) { event.preventDefault(); submit(draft); } }} placeholder="Ask the operations assistant…" rows={1} className="max-h-32 min-h-10 flex-1 resize-none bg-transparent px-2 py-2 text-sm outline-none placeholder:text-[hsl(var(--muted-foreground))]" data-testid="input-assistant-message" /><button type="submit" disabled={!draft.trim() || sendMessage.isPending || !context.online} className="grid size-10 place-items-center rounded-lg bg-[hsl(var(--foreground))] text-[hsl(var(--background))] transition-transform hover:-translate-y-0.5 disabled:cursor-not-allowed disabled:opacity-35" data-testid="button-send-message"><ArrowUp size={17} /></button></div><p className="mt-2 px-1 text-[10px] text-[hsl(var(--muted-foreground))]">Press Enter to send · Shift + Enter for a new line</p></form></div></section>
      <aside className="space-y-5"><div className="rounded-2xl border border-[hsl(var(--border))] bg-[hsl(var(--foreground))] p-5 text-[hsl(var(--background))]"><div className="flex items-center justify-between"><p className="font-mono text-[9px] uppercase tracking-[.18em] text-[hsl(var(--background)/.5)]">Discord quick start</p><Search size={15} className="text-[hsl(var(--accent))]" /></div><p className="mt-5 text-sm leading-6 text-[hsl(var(--background)/.78)]">In Discord, ask your question directly. The bot will answer conversationally and show confirmation before high-impact changes.</p><div className="mt-5 space-y-2">{suggested.length ? suggested.map((prompt, index) => <button key={prompt} onClick={() => submit(prompt)} className="group flex w-full items-start gap-2 rounded-lg border border-[hsl(var(--background)/.13)] px-3 py-2.5 text-left text-xs leading-5 text-[hsl(var(--background)/.78)] transition-colors hover:border-[hsl(var(--accent)/.65)] hover:bg-[hsl(var(--background)/.06)]" data-testid={`button-suggested-prompt-${index}`}><span className="mt-0.5 text-[hsl(var(--accent))]">0{index + 1}</span><span className="flex-1">{prompt}</span><ChevronRight size={13} className="mt-1 opacity-45 transition-transform group-hover:translate-x-0.5" /></button>) : <p className="text-xs text-[hsl(var(--background)/.5)]">No shortcuts configured yet.</p>}</div></div><div className="rounded-2xl border border-[hsl(var(--border))] bg-[hsl(var(--card))] p-5"><div className="flex items-center justify-between"><p className="font-mono text-[9px] uppercase tracking-[.18em] text-[hsl(var(--muted-foreground))]">Recent trail</p><Clock3 size={15} className="text-[hsl(var(--muted-foreground))]" /></div><div className="mt-4 space-y-4">{context.activity?.slice(0, 4).map((item) => <div key={item.id} className="flex gap-3" data-testid={`activity-preview-${item.id}`}><span className={`mt-1.5 size-1.5 shrink-0 rounded-full ${item.status === 'completed' ? 'bg-[hsl(var(--accent-foreground))]' : item.status === 'pending' ? 'bg-[hsl(var(--chart-4))]' : 'bg-[hsl(var(--destructive))]'}`} /><div className="min-w-0"><p className="truncate text-xs font-semibold">{item.action}</p><p className="mt-0.5 truncate text-[10px] text-[hsl(var(--muted-foreground))]">{item.detail || item.status}</p></div></div>)}</div><Link href="/activity" className="mt-5 flex items-center gap-1 text-[11px] font-semibold text-[hsl(var(--foreground))] hover:underline" data-testid="link-view-activity">View full trail <ChevronRight size={13} /></Link></div><div className="flex gap-3 rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--card)/.6)] p-4"><FileText size={15} className="mt-0.5 shrink-0 text-[hsl(var(--muted-foreground))]" /><p className="text-[11px] leading-5 text-[hsl(var(--muted-foreground))]">The assistant always shows confirmation before high-impact changes.</p></div></aside>
    </div>
    {confirming && <ConfirmPanel action={confirming} onConfirm={(note) => execute(confirming, true, note)} onCancel={() => setConfirming(null)} pending={executeAction.isPending} />}
  </div>;
}