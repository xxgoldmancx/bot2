import { Command } from 'lucide-react';

export function BrandMark({ compact = false }: { compact?: boolean }) {
  return (
    <div className="flex items-center gap-3" data-testid="brand-mark">
      <div className="relative grid size-9 place-items-center rounded-xl bg-[hsl(var(--accent))] text-[hsl(var(--accent-foreground))] shadow-[3px_3px_0_hsl(var(--accent-foreground)/.18)]">
        <Command size={18} strokeWidth={2.6} />
        <span className="absolute -right-1 -top-1 size-2 rounded-full border-2 border-[hsl(var(--sidebar))] bg-[hsl(var(--destructive))]" />
      </div>
      {!compact && (
        <div>
          <p className="text-sm font-bold leading-none tracking-[-.03em] text-[hsl(var(--sidebar-foreground))]">Staff Ops</p>
          <p className="mt-1 font-mono text-[9px] uppercase tracking-[.16em] text-[hsl(var(--sidebar-foreground)/.48)]">command center</p>
        </div>
      )}
    </div>
  );
}