export function PageSkeleton() {
  return <div className="animate-pulse space-y-5"><div className="h-3 w-24 rounded bg-[hsl(var(--muted))]" /><div className="h-9 w-72 rounded bg-[hsl(var(--muted))]" /><div className="h-4 w-[420px] max-w-full rounded bg-[hsl(var(--muted))]" /><div className="mt-10 h-48 rounded-xl bg-[hsl(var(--muted))]" /></div>;
}

export function ChatSkeleton() {
  return <div className="flex items-start gap-3"><div className="size-8 shrink-0 animate-pulse rounded-lg bg-[hsl(var(--muted))]" /><div className="space-y-2"><div className="h-3 w-32 animate-pulse rounded bg-[hsl(var(--muted))]" /><div className="h-10 w-64 animate-pulse rounded-lg bg-[hsl(var(--muted))]" /></div></div>;
}