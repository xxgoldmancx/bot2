import { useMemo, type ReactNode } from 'react';
import { Activity, BookOpen, CircleHelp, Command, LayoutDashboard, Radio, ShieldCheck } from 'lucide-react';
import { Link, useLocation } from 'wouter';
import { useGetAssistantContext } from '@workspace/api-client-react';
import { useHealthCheck } from '@workspace/api-client-react';
import { getGetAssistantContextQueryKey } from '@workspace/api-client-react';
import { BrandMark } from './brand-mark';
import type { StaffProfile } from '@/lib/types';

const nav = [
  { href: '/', label: 'Command center', icon: LayoutDashboard },
  { href: '/activity', label: 'Activity trail', icon: Activity },
  { href: '/capabilities', label: 'Capabilities', icon: ShieldCheck },
];

function Avatar({ staff, small = false }: { staff?: StaffProfile; small?: boolean }) {
  return (
    <div className={`grid ${small ? 'size-7 text-[10px]' : 'size-9 text-xs'} shrink-0 place-items-center rounded-full bg-[hsl(var(--accent))] font-bold text-[hsl(var(--accent-foreground))]`} data-testid="avatar-staff">
      {staff?.initials ?? '—'}
    </div>
  );
}

export function AppShell({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  const { data: context } = useGetAssistantContext({ query: { queryKey: getGetAssistantContextQueryKey() } });
  const { data: health } = useHealthCheck();
  const currentLabel = useMemo(() => nav.find((item) => item.href === location)?.label ?? 'Command center', [location]);
  const online = context?.online ?? health?.status === 'ok';

  return (
    <div className="app-noise min-h-[100dvh] bg-[hsl(var(--background))] text-[hsl(var(--foreground))]">
      <aside className="fixed inset-y-0 left-0 z-30 hidden w-[248px] flex-col border-r border-[hsl(var(--sidebar-border))] bg-[hsl(var(--sidebar))] px-5 py-6 text-[hsl(var(--sidebar-foreground))] lg:flex">
        <BrandMark />
        <div className="mt-14 px-2">
          <p className="font-mono text-[9px] uppercase tracking-[.22em] text-[hsl(var(--sidebar-foreground)/.38)]">Workspace</p>
          <nav className="mt-4 space-y-1" aria-label="Primary navigation">
            {nav.map((item) => {
              const active = item.href === location;
              const Icon = item.icon;
              return (
                <Link key={item.href} href={item.href} className={`group flex items-center gap-3 rounded-lg px-3 py-3 text-sm transition-colors ${active ? 'bg-[hsl(var(--sidebar-accent))] font-semibold text-[hsl(var(--sidebar-foreground))]' : 'text-[hsl(var(--sidebar-foreground)/.58)] hover:bg-[hsl(var(--sidebar-accent)/.65)] hover:text-[hsl(var(--sidebar-foreground))]'}`} data-testid={`link-nav-${item.label.toLowerCase().replaceAll(' ', '-')}`}>
                  <Icon size={17} strokeWidth={active ? 2.2 : 1.8} />
                  <span>{item.label}</span>
                  {active && <span className="ml-auto size-1.5 rounded-full bg-[hsl(var(--accent))]" />}
                </Link>
              );
            })}
          </nav>
        </div>
        <div className="mt-auto">
          <div className="mb-5 border-t border-[hsl(var(--sidebar-border))] pt-5">
            <div className="flex items-center gap-3 px-2">
              <Avatar staff={context?.staff} small />
              <div className="min-w-0">
                <p className="truncate text-xs font-semibold" data-testid="text-staff-name">{context?.staff?.name ?? 'Loading profile'}</p>
                <p className="truncate text-[10px] text-[hsl(var(--sidebar-foreground)/.48)]">{context?.staff?.role ?? 'Staff member'}</p>
              </div>
              <div className={`ml-auto size-2 rounded-full ${online ? 'online-pulse bg-[hsl(var(--accent))]' : 'bg-[hsl(var(--destructive))]'}`} />
            </div>
          </div>
          <div className="rounded-lg border border-[hsl(var(--sidebar-border))] bg-[hsl(var(--sidebar-accent)/.55)] p-3">
            <div className="flex items-center gap-2 text-[10px] font-semibold uppercase tracking-[.12em] text-[hsl(var(--sidebar-foreground)/.68)]">
              <Radio size={12} className={online ? 'text-[hsl(var(--accent))]' : 'text-[hsl(var(--destructive))]'} />
              {online ? 'Systems online' : 'Connection issue'}
            </div>
            <p className="mt-2 text-[10px] leading-relaxed text-[hsl(var(--sidebar-foreground)/.4)]">Discord is the primary channel for your operations assistant.</p>
          </div>
        </div>
      </aside>

      <header className="sticky top-0 z-20 flex h-[72px] items-center justify-between border-b border-[hsl(var(--border))] bg-[hsl(var(--background)/.92)] px-5 backdrop-blur-md lg:ml-[248px] lg:px-10">
        <div className="flex items-center gap-3">
          <div className="lg:hidden"><BrandMark compact /></div>
          <div className="hidden items-center gap-2 text-xs text-[hsl(var(--muted-foreground))] sm:flex">
            <span className="font-mono uppercase tracking-[.14em]">Workspace</span>
            <span className="text-[hsl(var(--border))]">/</span>
            <span className="font-semibold text-[hsl(var(--foreground))]">{currentLabel}</span>
          </div>
          <div className="flex items-center gap-2 sm:hidden">
            <Command size={15} className="text-[hsl(var(--muted-foreground))]" />
            <span className="text-sm font-semibold">{currentLabel}</span>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <div className="hidden items-center gap-2 rounded-full border border-[hsl(var(--border))] bg-[hsl(var(--card))] px-3 py-1.5 font-mono text-[10px] uppercase tracking-[.08em] text-[hsl(var(--muted-foreground))] sm:flex">
            <span className={`size-1.5 rounded-full ${online ? 'bg-[hsl(var(--accent-foreground))] ring-2 ring-[hsl(var(--accent)/.35)]' : 'bg-[hsl(var(--destructive))]'}`} />
            {online ? 'Live' : 'Offline'}
          </div>
          <Avatar staff={context?.staff} />
        </div>
      </header>

      <main className="lg:ml-[248px]">{children}</main>

      <nav className="fixed bottom-0 left-0 right-0 z-30 flex border-t border-[hsl(var(--border))] bg-[hsl(var(--card)/.96)] p-2 backdrop-blur-md lg:hidden" aria-label="Mobile navigation">
        {nav.map((item) => {
          const active = item.href === location;
          const Icon = item.icon;
          return <Link key={item.href} href={item.href} className={`flex flex-1 flex-col items-center gap-1 rounded-lg py-2 text-[10px] font-medium ${active ? 'bg-[hsl(var(--accent)/.35)] text-[hsl(var(--foreground))]' : 'text-[hsl(var(--muted-foreground))]'}`} data-testid={`mobile-nav-${item.label.toLowerCase().replaceAll(' ', '-')}`}><Icon size={17} /><span>{item.label.replace('Command center', 'Home')}</span></Link>;
        })}
      </nav>
    </div>
  );
}

export function SectionEyebrow({ children }: { children: ReactNode }) {
  return <p className="font-mono text-[10px] font-medium uppercase tracking-[.2em] text-[hsl(var(--muted-foreground))]">{children}</p>;
}

export function PageHeading({ eyebrow, title, description }: { eyebrow: string; title: string; description: string }) {
  return <div className="stagger-in max-w-2xl"><SectionEyebrow>{eyebrow}</SectionEyebrow><h1 className="mt-3 text-3xl font-bold tracking-[-.055em] text-[hsl(var(--foreground))] sm:text-4xl">{title}</h1><p className="mt-3 text-sm leading-6 text-[hsl(var(--muted-foreground))]">{description}</p></div>;
}

export function EmptyState({ icon: Icon, title, text }: { icon: typeof BookOpen; title: string; text: string }) {
  return <div className="grid place-items-center rounded-xl border border-dashed border-[hsl(var(--border))] bg-[hsl(var(--card)/.6)] px-6 py-16 text-center"><div className="grid size-12 place-items-center rounded-xl bg-[hsl(var(--secondary))] text-[hsl(var(--muted-foreground))]"><Icon size={21} /></div><h3 className="mt-4 text-sm font-semibold">{title}</h3><p className="mt-2 max-w-xs text-xs leading-5 text-[hsl(var(--muted-foreground))]">{text}</p></div>;
}