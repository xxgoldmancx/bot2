# Staff Operations Bot

A chat-first internal operations copilot that lets staff ask for work, review proposed actions, and execute approved operations with an auditable activity trail.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/staff-ops-bot/src/` — staff-facing chat experience, activity trail, capability map, and shared shell
- `artifacts/api-server/src/routes/assistant.ts` — assistant context, message interpretation, action execution, and activity records
- `lib/api-spec/openapi.yaml` — source of truth for the assistant API contract
- `artifacts/staff-ops-bot/src/index.css` — application theme and visual tokens

## Architecture decisions

- The product is chat-first rather than dashboard-first; navigation is limited to the conversation, activity trail, and capability map.
- Consequential operations are represented as proposed actions and require explicit staff confirmation before execution.
- Assistant responses use an OpenAI-compatible model when `OPENAI_API_KEY` is configured, with a deterministic safe fallback for local development or unavailable model requests.
- Discord is the primary interaction channel: members can ask questions directly in plain messages. The `/cmd set-roles` slash command is reserved for configuring staff roles and LOA approver roles, so the bot requires the Discord Message Content privileged intent.
- Discord role names determine approval boundaries: Owner/Admin can run approved operations, Manager can create tasks and drafts, Staff can create drafts, and Viewer is read-only.
- A guild owner or Manage Server administrator can use `/cmd set-roles` to save the Owner, Admin, Manager, and Staff Discord role IDs, plus up to five optional LOA approver role IDs. Users without a configured staff role receive the exact access error instead of using the bot.
- Staff can submit a leave-of-absence request with a plain message such as `LOA: <details>`. The bot first asks whether the LOA starts on the request date or a manual `MM-DD-YYYY` date, then asks for the end date. It stores the completed request as pending, posts an approval embed that mentions every configured LOA approver role, and removes the buttons after the first authorized approval or decline.
- LOA approval messages are posted in `staff-resources`. A successful approval posts `<@user> has Requested LOA and has been approved` in `staff-updates` and grants the requester the `LOA` role. The bot needs View Channel/Send Messages in both channels and Manage Roles with the bot role above `LOA`.
- Verification is available to every server member, independent of staff roles. Create a text channel named `verify`, a role named `Verified`, and give the bot Manage Roles with its highest role above `Verified`. Members can use `!verify` in `verify`; asking how to verify shows the channel, steps, setup status, and current verification status.
- The initial operation layer uses an in-memory activity store so the first build is runnable without a schema migration; persistent records and real systems are the next integration step.

## Product

- Ask plain-language questions about current work and priorities.
- Generate reviewable drafts and structured follow-up actions.
- Execute approved operations through explicit confirmation cards.
- Review recent assistant activity and capability availability.
- Surface what the assistant can do without implying access to unconnected systems.

## User preferences

_Populate as you build — explicit user instructions worth remembering across sessions._

## Gotchas

- The API server is mounted under `/api`; the web app uses the shared proxy and generated API hooks.
- Staff ask questions directly in Discord. Administrators use `/cmd set-roles` to configure role IDs and optional `loa-role-1` through `loa-role-5` approvers; the bot registers `/cmd` globally at startup.
- Direct questions support lightweight everyday conversation and live weather lookups such as `weather in Boston`; weather requests use Open-Meteo directly and skip the AI model.
- Tool execution is intentionally bounded to the action IDs exposed by the assistant route. Add a capability and its confirmation behavior before exposing a new operation.
- `OPENAI_API_KEY` is a secret and must never be printed or committed.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
