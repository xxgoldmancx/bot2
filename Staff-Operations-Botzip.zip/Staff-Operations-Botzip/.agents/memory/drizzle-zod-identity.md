---
name: Drizzle identity insert schemas
description: A schema-generation constraint for PostgreSQL identity columns and drizzle-zod.
---

When using `generatedAlwaysAsIdentity()` with `createInsertSchema`, do not explicitly omit the generated `id`; drizzle-zod may not include that key in the generated insert schema.

**Why:** An explicit omit of a key that drizzle-zod already removed causes schema initialization and Drizzle Kit schema pushes to fail.

**How to apply:** Omit only the timestamp or other server-managed fields that are present in the generated schema, then run the database schema push before restarting services.